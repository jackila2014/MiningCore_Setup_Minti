﻿DROP TABLE shares;
DROP TABLE blocks;
DROP TABLE balances;
DROP TABLE payments;
