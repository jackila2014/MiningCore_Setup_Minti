﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Miningcore.Persistence.Repositories
{
    public enum SampleInterval
    {
        Hour = 1,
        Day
    }
}
