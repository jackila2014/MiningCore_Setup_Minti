﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Miningcore.Persistence.Repositories
{
    public enum SampleRange
    {
        Day = 1,
        Month
    }
}
